# TPLC

## Touche Pas la Covid

### Projet d'informatique de 3ème année

Réalisé par :
- Pierre-Luc Millet
- Théo Wattel
- Quentin Lourenco
- Augustin Mariage
- Armand Deffrennes
- Raphaël Fleury-Le-Vaiso


### Serveur disponible sur [Github](https://github.com/rfleuryleveso/tpc-server)

ISEN Lille - France
