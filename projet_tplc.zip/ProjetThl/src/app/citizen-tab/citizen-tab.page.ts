import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-tab',
  templateUrl: './citizen-tab.page.html',
  styleUrls: ['./citizen-tab.page.scss'],
})
export class CitizenTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
