export interface VaccineModel {
  date: Date;
  lab: string;
}
