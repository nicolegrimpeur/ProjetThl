export interface TestModel {
  date: Date;
  result: boolean;
  variant: string;
}
