export interface StatModel {
    date: string;
    dc_tot: string;
    dchosp: string;
    esms_cas: string;
    esms_dc: string;
    hosp: string;
    incid_dchosp: string;
    incid_hosp: string;
    incid_rad: string;
    incid_rea: string;
    rad: string;
    rea: string;
}
