export interface IdModel {
  _id: string;
}
