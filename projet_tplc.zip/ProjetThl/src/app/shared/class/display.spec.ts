import { Display } from './display';

describe('Display', () => {
  it('should create an instance', () => {
    expect(new Display()).toBeTruthy();
  });
});
