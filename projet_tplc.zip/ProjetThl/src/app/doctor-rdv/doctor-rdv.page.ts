import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-rdv',
  templateUrl: './doctor-rdv.page.html',
  styleUrls: ['./doctor-rdv.page.scss'],
})
export class DoctorRdvPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
