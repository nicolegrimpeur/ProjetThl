import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-tab',
  templateUrl: './doctor-tab.page.html',
  styleUrls: ['./doctor-tab.page.scss'],
})
export class DoctorTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
